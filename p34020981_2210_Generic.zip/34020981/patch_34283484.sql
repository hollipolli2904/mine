set define '^' verify off
prompt ...patch_34283484.sql
--------------------------------------------------------------------------------
--
-- Copyright (c) Oracle Corporation 1999 - 2022. All Rights Reserved.
--
-- NAME
--   patch_34283484.sql
--
-- DESCRIPTION
--   Allow workspace administrator user to exist.
--
-- MODIFIED   (MM/DD/YYYY)
--   jstraub   06/29/2022 - Created
--
--------------------------------------------------------------------------------

declare
    l_login_process clob := wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    c_landing_page        constant wwv_flow_platform_prefs.name%type := ''LANDING_PAGE_OVERRIDE'';',
'    l_schema_name         varchar2(256);',
'    l_p1                  varchar2(256)  := wwv_flow_provision.get_random_password(16);',
'    l_username_asserted   varchar2(4000) := wwv_flow_assert.enquote_name(upper(:P142_ADMIN));',
'    l_password_asserted   varchar2(4000) := wwv_flow_assert.enquote_name(:P142_ADMIN_PWD);',
'    l_sql                 varchar2(32767);',
'    user_exists           exception;',
'    pragma exception_init(user_exists,-01920);',
'begin',
'   if nvl(:P142_NEW_USER_YN,''Y'') = ''N'' then',
'       l_schema_name := :P142_DATABASE_USER;',
'       l_p1          := null;',
'   else',
'       l_schema_name := substr(wwv_flow_platform.get_preference(''SELF_SERVICE_SCHEMA_PREFIX'')',
'           ||wwv_flow_provisioning.generate_schema_for_workspace(:P142_COMPANY),1,128);',
'   end if;',
'',
'   if :P142_SECURITY_GROUP_ID is null then',
'       :P142_SECURITY_GROUP_ID := wwv_flow_id.next_val;',
'   end if;',
'   ',
'   if nvl(:P142_NEW_USER_YN,''N'') = ''Y'' and :P142_PASSWORD is not null then',
'       l_p1 := :P142_PASSWORD;',
'   end if;',
'',
'    wwv_flow_provisioning.auto_provision_company(',
'        p_company_name        => :P142_COMPANY,',
'        p_schema_name         => l_schema_name,',
'        p_schema_password     => l_p1,',
'        p_admin_password      => :P142_ADMIN_PWD,',
'        p_admin_userid        => :P142_ADMIN,',
'        p_security_group_id   => :P142_SECURITY_GROUP_ID',
'    );',
'    ',
'    update wwv_flow_fnd_user',
'       set FIRST_PASSWORD_USE_OCCURRED = ''Y'',',
'           CHANGE_PASSWORD_ON_FIRST_USE = ''N''',
'     where user_name = upper(:P142_ADMIN)',
'       and security_group_id = :P142_SECURITY_GROUP_ID;',
'',
'    --',
'    -- Create workspace administrator DB user ',
'    -- allow this user to already exist  ',
'    --',
'    l_sql := ''create user ''||l_username_asserted||'' identified by ''||l_password_asserted;',
'',
'    begin',
'        execute immediate l_sql;',
'    exception ',
'        when user_exists then',
'            null;',
'    end;',
'',
'    -- Now that the user created at least one workspace, reset the landing page if it is still set to',
'    -- the "first time login" state',
'    if wwv_flow_platform.get_preference(c_landing_page) = ''apex_admin'' then',
'        wwv_flow_platform.set_preference(p_preference_name  => c_landing_page,',
'                                         p_preference_value => '''');',
'    end if;',
'end;'));
begin
    update wwv_flow_step_processing
       set process_sql_clob = l_login_process
     where flow_id      between 4050            and 4050+9
       and flow_step_id between 142             and 142.9999
       and id           between 384609241818486114 and 384609241818486114.9999;
    commit;
end;
/
