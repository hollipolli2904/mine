set define '^' verify off
prompt ...wwv_flows_release
create or replace function wwv_flows_release wrapped 
a000000
369
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
64 89
JiJan6uyhh1B5NnoBJIYLHpFsF0wg8eZgcfLCNL+XhaWlm2u2fqWlkqW8tehLlbcXOfAsr2y
m17nx3TAM7h0ZQm4dIvmOdziuUE/cZ5nqcoOo3fwX9J0gVk9O75xc3HYiKau5x/T

/
