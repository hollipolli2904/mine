set define '^' verify off
prompt ...patch_34227903.sql
--------------------------------------------------------------------------------
--
-- Copyright (c) 1999, 2022, Oracle and/or its affiliates.
--
-- NAME
--   patch_34227903.sql
--
-- DESCRIPTION
--   Do not generate random password when builder authentication is DB.
--
-- MODIFIED   (MM/DD/YYYY)
--   joserive  08/23/2022 - Created
--
--------------------------------------------------------------------------------

begin
    update wwv_flow_step_processing
       set process_sql_clob = wwv_flow_string.join(wwv_flow_t_varchar2(
                'declare',
                '    l_random_password boolean;',
                'begin',
                '    --',
                '    -- if external user (who does not have to enter a password)',
                '    --    and password field is null',
                '    --    and either',
                '    --        - create / create_another pressed',
                '    --        - apply_changes pressed and user name changed',
                '    --',
                '    -- => create random password',
                '    --',
                '    if wwv_flow_authentication_dev.is_builder_password_required (',
                '           p_developer_yn => :P23_DEVELOPER )',
                '    then',
                '        l_random_password := false;',
                '    elsif :F4050_P23_WEB_PASSWORD is not null then',
                '        l_random_password := false;',
                '    elsif wwv_flow_authentication_dev.get_internal_authentication = ''DB'' then',
                '        l_random_password := false;',
                '    elsif :request in (''CREATE'',''CREATE_ANOTHER'') then',
                '        l_random_password := true;',
                '    elsif :request = ''Apply_Changes'' then',
                '        for c1 in ( select user_name',
                '                      from wwv_flow_fnd_user',
                '                     where user_id = :F4050_P23_USER_ID',
                '                       and security_group_id = :F4050_P23_SECURITY_GROUP_ID',
                '                       and user_name         <> :F4050_P23_USER_NAME )',
                '        loop',
                '            l_random_password := true;',
                '        end loop;',
                '    end if;',
                '    ',
                '    if l_random_password then',
                '        :F4050_P23_WEB_PASSWORD   := wwv_flow_authentication_dev.create_shadow_user_password;',
                '        :F4050_P23_CONFIRM_PASSWD := :F4050_P23_WEB_PASSWORD;',
                '    end if;',
                'end;')) 
     where flow_id      between 4050               and 4059
       and flow_step_id between 23                 and 23.9999
       and id           between 341059407111970570 and 341059407111970570.9999;
    commit;
end;
/