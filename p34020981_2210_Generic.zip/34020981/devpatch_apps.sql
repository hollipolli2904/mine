set define '^' verify off
set concat on
set concat .
prompt ...devpatch_apps.sql

Rem  Copyright (c) 1999, 2022, Oracle and/or its affiliates.
Rem
Rem    NAME
Rem      devpatch_apps.sql
Rem
Rem    DESCRIPTION
Rem      Application Express patch for a full development installation.
Rem
Rem    MODIFIED   (MM/DD/YYYY)
Rem    vuvarov     02/09/2022 - Created

define APPUN    = 'APEX_220100'

alter session set current_schema = ^APPUN;

-------------------------------------------------------------------
-- Patch files that update 4xxx series apps
-- @@patch_123456.sql
-------------------------------------------------------------------
@@patch_34283484.sql
@@patch_34265083.sql
@@patch_34277485.sql
@@patch_34178095.sql
@@patch_34416979.sql
@@patch_34353896.sql
@@patch_34227903.sql

-------------------------------------------------------------------
-- Commit after DML changes to metadata
-------------------------------------------------------------------
commit;
