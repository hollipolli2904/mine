set define '^' verify off
prompt ...patch_34416979.sql
--------------------------------------------------------------------------------
--
-- Copyright (c) Oracle Corporation 1999 - 2022. All Rights Reserved.
--
-- NAME
--   patch_34416979.sql
--
-- DESCRIPTION
--   Fix MLE view names for DB 23C
--
-- MODIFIED   (MM/DD/YYYY)
--   sdobre   07/26/2022 - Created
--
--------------------------------------------------------------------------------

begin
    -- 1. 5000 region      1669310506132606 dba_env_imports_mle    => dba_mle_env_imports
    -- 2. 5000 process     1670308609132616 dba_envs_mle           => dba_mle_envs
    -- 3. 5005 validation  3020671452205844 dba_envs_mle           => dba_mle_envs
    -- 4. 5010 region      2985508865654513 dba_modules_mle        => dba_mle_modules
    -- 5. 5010 process     1740390301992229 dba_modules_mle        => dba_mle_modules
    -- 6. 5015 validation  2984589877654503 dba_modules_mle        => dba_mle_modules

    -- 1
    update wwv_flow_page_plugs
       set plug_source = replace( plug_source, 'dba_env_imports_mle', 'dba_mle_env_imports' )
     where flow_id between 4500 and 4509
       and page_id >= 5000
       and page_id <  5000 + 1
       and id >= 1669310506132606
       and id <  1669310506132606 + 1;
    
    -- 2
    update wwv_flow_step_processing
       set process_sql_clob = replace( process_sql_clob, 'dba_envs_mle', 'dba_mle_envs' )
     where flow_id between 4500 and 4509
       and flow_step_id >= 5000
       and flow_step_id <  5000 + 1
       and id >= 1670308609132616
       and id <  1670308609132616 + 1;

    -- 3
    update wwv_flow_step_validations
       set validation = replace( validation, 'dba_envs_mle', 'dba_mle_envs' )
     where flow_id between 4500 and 4509
       and flow_step_id >= 5005
       and flow_step_id <  5005 + 1
       and id >= 3020671452205844
       and id <  3020671452205844 + 1;

    -- 4
    update wwv_flow_page_plugs
       set plug_source = replace( plug_source, 'dba_modules_mle', 'dba_mle_modules' )
     where flow_id between 4500 and 4509
       and page_id >= 5010
       and page_id <  5010 + 1
       and id >= 2985508865654513
       and id <  2985508865654513 + 1;

    -- 5
    update wwv_flow_step_processing
       set process_sql_clob = replace( process_sql_clob, 'dba_modules_mle', 'dba_mle_modules' )
     where flow_id between 4500 and 4509
       and flow_step_id >= 5010
       and flow_step_id <  5010 + 1
       and id >= 1740390301992229
       and id <  1740390301992229 + 1;

    -- 6
    update wwv_flow_step_validations
       set validation = replace( validation, 'dba_modules_mle', 'dba_mle_modules' )
     where flow_id between 4500 and 4509
       and flow_step_id >= 5015
       and flow_step_id <  5015 + 1
       and id >= 2984589877654503
       and id <  2984589877654503 + 1;

    commit;

end;
/
