set define '^' verify off
prompt ...patch_34353896.sql
--------------------------------------------------------------------------------
--
-- Copyright (c) Oracle Corporation 1999 - 2022. All Rights Reserved.
--
-- NAME
--   patch_34353896.sql
--
-- DESCRIPTION
--   Reset Restricted Characters for items where it was wrongly set
--
-- MODIFIED   (MM/DD/YYYY)
--   sravva   08/04/2022 - Created
--
--------------------------------------------------------------------------------
declare
    procedure clear_restricted_characters(
        p_flow_step_id in number,
        p_id           in number )
    is
    begin
        update wwv_flow_step_items
           set restricted_characters = null
         where security_group_id = 10
           and flow_id between 4000 and 4000 + 9
           and flow_step_id >= p_flow_step_id
           and flow_step_id < p_flow_step_id + 1
           and id >= p_id
           and id <  p_id + 1;
    end clear_restricted_characters;
begin
    -- 4000:1811, item P1811_TABLE_OWNER -- 1638143746350808
    clear_restricted_characters(
        p_flow_step_id => 1811,
        p_id           => 1638143746350808 );

    -- 4000:2501, item P2501_TABLE_OWNER -- 28115848614159062
    clear_restricted_characters(
        p_flow_step_id => 2501,
        p_id           => 28115848614159062 );

    -- 4000:2515, item P2515_TABLE_OWNER -- 8235301279249323
    clear_restricted_characters(
        p_flow_step_id => 2515,
        p_id           => 8235301279249323 );

    -- 4000:2518, item P2518_TABLE_OWNER -- 5584652589470648
    clear_restricted_characters(
        p_flow_step_id => 2518,
        p_id           => 5584652589470648 );

    -- 4000:2507, item P2507_OWNER       -- 10901163486976086
    clear_restricted_characters(
        p_flow_step_id => 2507,
        p_id           => 10901163486976086 );

    -- 4000:542 , item P542_OWNER        -- 1443511606800506
    clear_restricted_characters(
        p_flow_step_id => 542,
        p_id           => 1443511606800506 );

    -- 4000:701 , item P701_OWNER        -- 1446316855805193
    clear_restricted_characters(
        p_flow_step_id => 701,
        p_id           => 1446316855805193 );

    commit;
end;
/