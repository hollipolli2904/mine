set define '^' verify off
prompt ...patch_34265083.sql
--------------------------------------------------------------------------------
--
-- Copyright (c) Oracle Corporation 1999 - 2022. All Rights Reserved.
--
-- NAME
--   patch_34265083.sql
--
-- DESCRIPTION
--   Allow workspace admin user to exist when creating a workspace with new schema.
--
-- MODIFIED   (MM/DD/YYYY)
--   jstraub   06/29/2022 - Created
--
--------------------------------------------------------------------------------
begin
    delete from wwv_flow_step_validations
     where flow_id      between 4050            and 4050+9
       and flow_step_id between 142             and 142.9999
       and id           between 22928760286012306 and 22928760286012306.9999;
    commit;
end;
/
