set define '^' verify off
prompt ...patch_34277485.sql
--------------------------------------------------------------------------------
--
-- Copyright (c) 1999, 2022, Oracle and/or its affiliates.
--
-- NAME
--   patch_34277485.sql
--
-- DESCRIPTION
--   Fix workspace success message link to populate username correctly on login page.
--
-- MODIFIED   (MM/DD/YYYY)
--   jstraub   06/29/2022 - Created
--
--------------------------------------------------------------------------------

begin
    update wwv_flow_step_processing
       set process_success_message = regexp_replace(process_success_message, 'href="[^"]+"',
                                                    'href="f?p=4550:1:::::F4550_P1_COMPANY,F4550_P1_USERNAME:' ||
                                                    '&P142_COMPANY!ATTR.,&P142_ADMIN!ATTR."')
     where flow_id      between 4050            and 4050+9
       and flow_step_id between 142             and 142.9999
       and id           between 384609241818486114 and 384609241818486114.9999
       and instr(process_success_message, '&P142_DATABASE_USER!ATTR.') > 0;
    commit;
end;
/
