set define '^' verify off
set concat on
set concat .
prompt ...devpatch.sql

Rem  Copyright (c) 1999 - 2022, Oracle and/or its affiliates. All rights reserved.
Rem
Rem    NAME
Rem      devpatch.sql
Rem
Rem    DESCRIPTION
Rem      Application Express patch for a full development installation.
Rem
Rem    MODIFIED   (MM/DD/YYYY)
Rem    hfarrell    10/13/2020 - Created

define APPUN    = 'APEX_220100'

alter session set current_schema = SYS;
--------------------------------------------------------------------------------
-- Grants
--------------------------------------------------------------------------------
grant select on sys.dba_external_tables to ^APPUN;

alter session set current_schema = ^APPUN;

---------------------------------------------------------------------------
-- Compilation of package specifications
-- @@foo.sql
---------------------------------------------------------------------------

---------------------------------------------------------------------------
-- Compilation of views
-- @@dev_views.sql
---------------------------------------------------------------------------

-------------------------------------------------------------------
-- Compilation of package bodies
-- @@wwv_flow_lov_dev.plb
-------------------------------------------------------------------
@@wwv_flow_approval_dev.plb
@@wwv_flow_authentication_dev.plb
@@wwv_flow_backup.plb
@@wwv_flow_report_dev.plb
--------------------------------------------------------------------------------
-- Grants and public synonyms
--------------------------------------------------------------------------------

-- See bug 34416979
declare
    procedure ddl ( p_sql in varchar2 ) is
    begin
        execute immediate p_sql;
    exception
        when others then null;
    end ddl;
begin
    if sys.dbms_db_version.version >= 23 then
        ddl( 'grant read on sys.dba_mle_envs        to ^APPUN' );
        ddl( 'grant read on sys.dba_mle_modules     to ^APPUN' );
        ddl( 'grant read on sys.dba_mle_env_imports to ^APPUN' );
    end if;
end;
/

-- only recompile this package after the previous privs have been granted
@@wwv_flow_sw_object_feed.plb

-------------------------------------------------------------------
-- patch files
-- @@patch_123456.sql
-------------------------------------------------------------------

-- commit after dml changes to metadata
commit;
