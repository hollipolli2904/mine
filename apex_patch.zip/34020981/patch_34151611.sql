set define '^' verify off
prompt ...patch_34151611.sql
--------------------------------------------------------------------------------
--
-- Copyright (c) 1999, 2022, Oracle and/or its affiliates.
--
-- NAME
--   patch_34151611.sql
--
-- DESCRIPTION
--   Add unique key constraint for wwv_flow_task_def_actions table.
--
-- MODIFIED   (MM/DD/YYYY)
--   ralmuell   05/11/2022 - Created
--
--------------------------------------------------------------------------------

prompt ... Add unique key constraint wwv_task_def_act_uk for table wwv_flow_task_def_actions

declare

    type t_taskdef_actions_uk    is record (
        task_def_id wwv_flow_task_def_actions.task_def_id%type,
        name        wwv_flow_task_def_actions.name%type );

    type t_taskdef_actions_table is table of t_taskdef_actions_uk;

    g_taskdef_actions_table t_taskdef_actions_table := t_taskdef_actions_table();

    procedure calculate_dup_taskdef_actions
    is
    begin
        select task_def_id,
               name
          bulk collect into g_taskdef_actions_table
          from wwv_flow_task_def_actions
      group by task_def_id, name
        having count(*) > 1;
    end calculate_dup_taskdef_actions;

    procedure resolve_dup_taskdef_actions
    is
    begin
        forall i in 1 .. g_taskdef_actions_table.count
            update wwv_flow_task_def_actions
               set name =
                    case
                        when rownum = 1 then name
                        else name || '_' || rownum
                    end
             where task_def_id = g_taskdef_actions_table(i).task_def_id and
                   name        = g_taskdef_actions_table(i).name;
        commit;
    end resolve_dup_taskdef_actions;

    function exists_task_def_act_uk
    return boolean
    is
        l_exists number;
    begin
        select 1
          into l_exists
          from sys.all_constraints
         where owner = wwv_flow.g_flow_schema_owner and
               table_name      = 'WWV_FLOW_TASK_DEF_ACTIONS' and
               constraint_name = 'WWV_TASK_DEF_ACT_UK' and
               constraint_type = 'U';
        return true;
    exception
        when no_data_found then
            return false;
    end exists_task_def_act_uk;

    procedure create_wwv_task_def_act_uk
    is
        l_stmt varchar2(1000);
    begin
        l_stmt := 'alter table wwv_flow_task_def_actions add constraint wwv_task_def_act_uk unique (task_def_id, name) using index compress 1';
        execute immediate l_stmt;
    end create_wwv_task_def_act_uk;

begin
    if not exists_task_def_act_uk then
        calculate_dup_taskdef_actions;
        resolve_dup_taskdef_actions;
        create_wwv_task_def_act_uk;
    end if;
end;
/
