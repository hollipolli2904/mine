set define '^' verify off
prompt ...patch_34178095.sql
--------------------------------------------------------------------------------
--
-- Copyright (c) Oracle Corporation 1999 - 2022. All Rights Reserved.
--
-- NAME
--   patch_34178095.sql
--
-- DESCRIPTION
--   Remove g_cloud condition from synonyms in SQL Workshop.
--
-- MODIFIED   (MM/DD/YYYY)
--   jstraub   06/30/2022 - Created
--
--------------------------------------------------------------------------------

begin
    update wwv_flow_list_items
       set list_item_disp_cond_type   = null
           ,list_item_disp_condition  = null
           ,list_item_disp_condition2 = null
     where flow_id      between 4500            and 4500+9
       and id           between 108268718537975278 and 108268718537975278.9999;

    update wwv_flow_list_items
       set list_item_disp_cond_type   = null
           ,list_item_disp_condition  = null
           ,list_item_disp_condition2 = null
     where flow_id      between 4500            and 4500+9
       and id           between 960228917980286937 and 960228917980286937.9999;

    update wwv_flow_list_items
       set list_item_disp_cond_type   = null
           ,list_item_disp_condition  = null
           ,list_item_disp_condition2 = null
     where flow_id      between 4500            and 4500+9
       and id           between 23678002029115528 and 23678002029115528.9999;

    commit;
end;
/
