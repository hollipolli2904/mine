# Oracle Application Express (APEX) Product Version #  : 22.1.x
#
# Patch Set Exception : Bug 34020981 - PSE BUNDLE FOR APEX 22.1 (PSES ON TOP OF 22.1.x)
#
# Platform Patch for  : Generic - Platform independent
#
# DATE : August 11, 2022
#
# This document describes how you can install the Patch Set Exception on your Oracle APEX 22.1.x instance.
#
#
# (I) Requirements:
#----------------------------
# Before you install the patch, ensure that you meet the following requirement:
#
#    - You must be using Oracle APEX Product Version #  : 22.1.x
#
# If you do NOT meet this requirement, or are not certain that you meet
# the requirement, please log a Service Request and Support will make
# a determination about whether you should apply this patch.
#
#
# (II) Bugs Fixed by this patch:
# ----- PATCH_VERSION: 1 -----
# 34151611 - MISSING '/' IN TAB.SQL APPROVALS COMPONENT DDL
# 34151906 - CAN'T SET 29 FEB IN DATEPICKER WHEN IT'S A LEAP YEAR
# 34052422 - CREATE FORM AND REPORT PAGE WIZARD GENERATES FORMAT MASKS FOR HIDDEN COLUMNS
# 34140222 - ORACLE APPLICATION EXPRESS - INTERMITTENT 500 ERROR WITH OHS 12C. EMPTY RESPONSE HEADER NAMES GENERATED
# 31042456 - HIGHLIGHT IN A SAVED INTERACTIVE GRID DISAPPEARS IF FILTERS/STRETCH COLUMN WIDTHS ARE USED
# 34021265 - UNEXPECTED FOCUS SHIFT AFTER CHANGING REGION TYPE IN PAGE DESIGNER
# 34119093 - WWV_FLOW_MAIL.BACKGROUND CALLS DBMS_SESSION.SET_IDENTIFIER WITH A TOO LONG ID
# 34123145 - "REST ENABLED QUERY" REST SOURCE TYPE USES TOO SMALL FETCH SIZE WHEN "ALLOW FETCH ALL ROWS" IS TURNED ON
# 34123261 - REST SOURCE TYPE "REST ENABLED SQL" SENDS "LOCAL FILTERS" TO THE REMOTE SERVER
# 34142592 - AUTOMATIC BACKUP NOT WORKING FOR APPLICATIONS WITH LARGE NUMBERS OF CHANGES
# 34170140 - SAML AUTH: ASSERTION CAN NOT BE VERIFIED IF IT CONTAINS NEWLINES
# 34188499 - REST ENABLED SQL: SOME ENDPOINTS (OCI MYSQL) RESPOND WITH HTTP-404, IF THE ENDPOINT URL HAS A TRAILING SLASH
# 34185616 - REGRESSION: OVERALL AGGREGATES MISSING IN REPORT DOWNLOADS
# 33491949 - FRIENDLY URL'S ARE NOT WORKING WHEN APP ALIAS OR PAGE ALIAS ARE NUMBERS
# 34215142 - REGRESSION: CHECKBOX GROUP ITEM VALUE NOT SENT TO SERVER, FAILING VALIDATION
# 34122298 - REGRESSION: INTERACTIVE GRID POPUP LOV COLUMN WITH MANUAL ENTRY = ON LEADS TO ORA 6553 ON ROW SEARCH
# 34054368 - REGRESSION: MULTISELECT POPUPLOV W/ COMMA SEP TREATS CSV VALUES AS ONE
# 34004879 - REGION DISPLAY SELECTOR TITLES DO NOT RESPECT COMPONENT-BASED AUTHORIZATION SCHEMES
# 34007404 - JQUERY DATEPICKER - MINUTES AND HOURS HAS THE WRONG ORDER
# 34233744 - UNIVERSAL THEME MISSING FLEX UTILITY CLASSES
# ----- PATCH_VERSION: 2 -----
# 34258334 - REGRESSION: PDF DOWNLOAD DOES NO LONGER SUPPORT BR TAGS / LINE BREAKS
# 34266195 - INTERACTIVE REPORT WRONG GROUP BY RESULT IF GROUP BY COLUMN HTML EXPRESSION BUILT USING OTHER COLUMN
# 34263099 - PROPERTY EDITOR: CODE EDITOR SOMETIMES LOSES EDITS ON RE-VALIDATION
# 34263394 - UNIQUE APP ALIAS GENERATED ON IMPORT CAN BECOME EXTREMELY LONG FOR COMMONLY IMPORTED APPS
# 34283484 - STABLE: GETTING ORA-01920 UPON CREATING WORKSPACE USING EXISTING SCHEMA
# 34265083 - ADB: CANNOT REUSE WORKSPACE ADMINISTRATOR ACCOUNT FOR SECOND WORKSPACE
# 34277485 - ADB: NEW WORKSPACE LINK IS MISSING THE PRE-POPULATED USERNAME
# 34178095 - ADB: ENABLE SYNONYMS OBJECTS IN OBJECT BROWSER
# ----- PATCH_VERSION: 3 -----
# 34395538 - PDF DOWNLOAD GETS CORRUPTED
# ----- NEW IN LATEST PATCH_VERSION: 4 -----
# 34320319 - REGRESSION: ERROR DOWNLOADING REPORT W/ FORMAT MASK USING SUBSTITUTION VARIABLE
# 34353896 - AJAX ERROR WHEN THE SCHEMA IS NOT ASSIGNED TO THE WORKSPACE BUT THE APP PARSING SCHEMA HAS PRIVILEGES ON THE OBJECT
#
# (III) Patch Installation Instructions:
# ---------------------------------------
# To apply the patch
#
#  1. Download the p34020981_221_GENERIC.zip patch set installation archive to a directory that is not the Oracle home directory or under the Oracle home directory.
#
#  2. Unzip and extract the installation files by double-clicking p34020981_221_GENERIC.zip in a Microsoft Windows based system, or entering the following command to unzip on a UNIX or Linux based system:
#
#   $ unzip p34020981_221_GENERIC.zip
#
#  3. Preventing Access to Oracle REST Data Services
#
#     It is important that no developers or end users access Oracle APEX while you are applying the patch. This section describes how to prevent access to Oracle APEX.
#
#     Stopping Oracle REST Data Services:
#
#        To learn more about stopping the Oracle REST Data Services server, see Oracle REST Data Services Installation and Configuration Guide:
#
#        http://docs.oracle.com/cd/E56351_01/doc.30/e56293/toc.htm
#
#
#  4. Set your current directory to the "" directory where you unzipped the p34020981_221_GENERIC.zip file.
#
#  5. Set the NLS_LANG environment variable, making sure that the character set is AL32UTF8. For example:
#
#     Bourne or Korn shell:
#
#       NLS_LANG=American_America.AL32UTF8
#       export NLS_LANG
#
#     C shell:
#
#       setenv NLS_LANG American_America.AL32UTF8
#
#     For Windows based systems:
#
#       set NLS_LANG=American_America.AL32UTF8
#
#  6. Connect to the database where Oracle APEX is installed as the SYS user and run catpatch.sql or catpatch_con.sql as in the following examples:
#
#     sqlplus "sys/ as sysdba" @catpatch.sql        -- for Oracle Database 12.1 and newer, for non-CDB, for CDB where Oracle APEX is not installed in the root, and for PDB where APEX is not installed in the root
#     sqlplus "sys/ as sysdba" @catpatch_con.sql    -- for CDB where Oracle APEX is installed in the root
#     sqlplus "sys/ as sysdba" @catpatch_appcon.sql -- for installations where Oracle APEX is installed in an application container
#
#  7. Install the Patch Set Exception's changes in the images directory
#
#       Copy the images directory of the patch to the /images folder of the Oracle APEX installation directory images sub directory.
#
#       Assuming the p34020981_221_GENERIC.zip file was unzipped to c:\temp on Windows and /tmp on Linux
#
#       On a Windows system, run a command from a command prompt similar to the following example:
#
#           xcopy /E /I c:\temp\images ORACLE_APEX_HOME\apex\images
#
#       On UNIX or Linux based systems, run a command similar to the following example:
#
#           cp -rf /tmp/images ORACLE_APEX_HOME/apex
#
#       In the preceding syntax examples, ORACLE_APEX_HOME is the existing Oracle APEX installation location. For example, c:\oracle\apex_22.1 on Windows and /oracle/apex_22.1 on Linux.
#
#  8. Starting Oracle APEX
#
#    - Starting Oracle REST Data Services
#
#       To learn more about starting the Oracle REST Data Services server, see Oracle REST Data Services Installation and Configuration Guide:
#
#           http://docs.oracle.com/cd/E56351_01/doc.30/e56293/toc.htm
#
#
# (IV) To confirm the patch has been applied:
# --------------------------------------------
#
#    I. Review the Product Build number on your instance
#
#       - Log into your workspace.
#
#       - Review the Product Build number displayed in the lower right corner.
#
#         If your instance has been patched, the build number will be 22.1.x, where x is the PATCH_VERSION. For example, 22.1.2.
#         In your instance has not been patched, the build number will be 22.1.x.
#
#   II. Review the About dialog on your instance
#
#       - Log into your workspace.
#
#       - Click 'Help' > 'About'.
#
#       - Review the Details section:
#
#         'Patch Version' will display the version of the patch installed.
#         'Last Patch Time' will display the patch installation date and time.
#         These values will only be visible on a patched instance.
#
#
#  III. Start SQL*Plus and connect to the database where Oracle APEX is installed as SYS. For example:
#
#         - On Windows:
#
#                 SYSTEM_DRIVE:\> sqlplus /nolog
#                 SQL> CONNECT SYS as SYSDBA
#                 Enter password: SYS_password
#
#         - On UNIX and Linux:
#
#                 $ sqlplus /nolog
#                 SQL> CONNECT SYS as SYSDBA
#                 Enter password: SYS_password
#
#            Enter the following statement to verify the patch with patch_number 34020981 has been installed:
#
#                 select patch_version, installed_on
#                   from apex_patches
#                  where patch_number = 34020981;
#
#            If the parameter exists, its value is the timestamp for when the patch was applied.
#
#
# EOF README.txt
