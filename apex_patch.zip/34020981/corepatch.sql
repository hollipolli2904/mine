set define '^' verify off concat on
set concat .

define PATCH_VERSION        = '4'
define PATCH_IMAGES_VERSION = '22.1.0'
define PATCH_ID             = '34020981'
define APPUN                = 'APEX_220100'

alter session set current_schema = SYS;

column   APEX_SCHEMA  new_val APEX_SCHEMA

select schema  APEX_SCHEMA
  from sys.dba_registry
 where comp_id = 'APEX'
   and schema = '^APPUN.'
/

declare
    invalid_alter_priv exception;
    pragma exception_init(invalid_alter_priv,-02248);
begin
    execute immediate 'alter session set "_ORACLE_SCRIPT"=true';
exception
    when invalid_alter_priv then
    null;
end;
/

--==============================================================================
prompt ... Disabling Jobs
--==============================================================================
declare
    l_jobs varchar2(32767);
begin
    --
    -- Fetch all enabled jobs
    --
    select ':'||
           listagg(job_name,':')
           within group (order by job_name)||
           ':'
      into l_jobs
      from sys.dba_scheduler_jobs
     where owner    =    '^APPUN'
       and enabled  =    'TRUE'
       and job_name like 'ORACLE_APEX_%'
     order by 1;
    --
    -- Store in COREPATCH_DISABLED_JOBS, or exit if the parameter already
    -- exists, which could be after re-running a failed patch.
    --
    begin
        insert into ^APPUN..wwv_flow_platform_prefs (
            id, name, value, security_group_id )
        values (
            -1, 'COREPATCH_DISABLED_JOBS', l_jobs, 10 );
        commit;
    exception when dup_val_on_index then
        return;
    end;
    --
    -- Disable
    --
    for i in ( select job_name,
                      state
                 from sys.dba_scheduler_jobs
                where owner   = '^APPUN'
                  and enabled = 'TRUE'
                  and instr (
                          l_jobs,
                          ':'||job_name||':' ) > 0
                order by 1 )
    loop
        sys.dbms_output.put_line('... disabling '||i.job_name);
        sys.dbms_scheduler.disable (
            name  => '^APPUN..'||i.job_name,
            force => true );
        if i.state = 'RUNNING' then
            sys.dbms_output.put_line('... stopping job');
            begin
                sys.dbms_scheduler.stop_job (
                    job_name => '^APPUN..'||i.job_name,
                    force    => false );
            exception when others then
                begin
                    sys.dbms_output.put_line('... stopping with force=>true');
                    sys.dbms_scheduler.stop_job (
                        job_name => '^APPUN..'||i.job_name,
                        force    => true );
                exception when others then null;
                end;
            end;
        end if;
    end loop;
end;
/

--==============================================================================
-- Install SYS objects
--==============================================================================

--
-- Compile wwv_dbms_sql.plb with original conditional compilation settings. Do
-- not do this in an application container, it would result in ORA-44201 during
-- sync.
--
col old_ccflags noprint new_val old_ccflags
col wwv_ccflags noprint new_val wwv_ccflags

-- select ( select sys.dbms_assert.enquote_literal(value)
--            from sys.v_$parameter
--           where name='plsql_ccflags' ) old_ccflags,
--        ( select sys.dbms_assert.enquote_literal (
--                     case
--                     when exists (select null
--                                    from sys.dba_registry
--                                   where comp_id = 'APEX' )
--                     then plsql_ccflags
--                     end )
--            from sys.dba_plsql_object_settings
--           where owner = 'SYS'
--             and name  = 'WWV_DBMS_SQL_^APPUN'
--             and type  = 'PACKAGE BODY' ) wwv_ccflags
--   from sys.dual
-- /
-- declare
--     l_stmt varchar2(4000);
-- begin
--     if ^wwv_ccflags is not null then
--         l_stmt := q'~alter session set plsql_ccflags=^wwv_ccflags~';
--         sys.dbms_output.put_line(l_stmt);
--         execute immediate l_stmt;
--     end if;
-- end;
-- /
--
-- @@wwv_dbms_sql.plb
--
-- declare
--     l_stmt varchar2(4000);
-- begin
--     if ^wwv_ccflags is not null then
--         l_stmt := q'~alter session set plsql_ccflags=^old_ccflags~';
--         sys.dbms_output.put_line(l_stmt);
--         execute immediate l_stmt;
--     end if;
-- end;
-- /

@@validate_apex.sql x x ^APPUN

alter session set current_schema = ^APPUN;

--==============================================================================
-- Views / other DDL
--==============================================================================
begin
    for i in ( select null
                 from dual
                where not exists ( select null
                                     from sys.dba_tab_privs
                                    where grantee    = '^APPUN'
                                      and owner      = 'SYS'
                                      and table_name = 'USER_OBJECTS' ))
    loop
        execute immediate 'grant select on sys.user_objects to ^APPUN';
    end loop;
end;
/

--==============================================================================
-- Add unique key constraint for wwv_flow_task_def_actions and handle dups
--==============================================================================
@@patch_34151611.sql

--==============================================================================
-- Specs/Bodies (1)
--==============================================================================


--==============================================================================
-- New Instance Parameter
--==============================================================================
declare
    l_cnt number;
begin
    select count(*) into l_cnt
      from wwv_flow_platform_prefs
     where name = 'IMAGE_PREFIX';

    if l_cnt = 0 and not wwv_flow_global.g_cloud then
        wwv_flow_platform.set_preference('IMAGE_PREFIX',wwv_flow_image_prefix.g_image_prefix);
    end if;
end;
/

--==============================================================================
-- Specs
--==============================================================================
@@flows_release.sql

--==============================================================================
-- Bodies for changed specs
--==============================================================================

--==============================================================================
-- Other bodies
--==============================================================================
@@flow.plb
@@plug.plb
@@wwv_flow_authentication.plb
@@wwv_flow_authentication_saml.plb
@@wwv_flow_data_export.plb
@@wwv_flow_debug.plb
@@wwv_flow_exec_remote.plb
@@wwv_flow_exec_web_src_restsql.plb
@@wwv_flow_imp.plb
@@wwv_flow_interactive_grid.plb
@@wwv_flow_ir_render.plb
@@wwv_flow_mail.plb
@@wwv_flow_response.plb
@@wwv_flow_security.plb
@@wwv_flow_session_state.plb


--==============================================================================
-- Metadata changes
--==============================================================================

--==============================================================================
-- Missing grants
--==============================================================================

--==============================================================================
-- Reinstall Universal Theme
--==============================================================================

--==============================================================================
-- Compilation of development package specifications and bodies. In certain CDB scenarios, development objects may exist
-- even if there are no 4xxx apps.
--==============================================================================
set define '^'
column thescript new_val script
set termout off
select case when f4000_cnt > 0 then 'devpatch.sql'
            when (select count(*)
                    from sys.dba_objects
                   where owner = '^APPUN.'
                     and object_name = 'WWV_FLOW_AUTHENTICATION_DEV'
                     and object_type = 'PACKAGE') > 0 then 'devpatch.sql'
            else 'null1.sql'
       end as thescript
  from (select count(*) as f4000_cnt from wwv_flows where id = 4000);
set termout on
@@^script

set define '^'
column thescript new_val script
set termout off
select decode(count(*),0,'null1.sql','devpatch_apps.sql') thescript from wwv_flows where id = 4000;
set termout on
@@^script

--==============================================================================
-- Set Revised Build Version in internal apps
--==============================================================================
set define '^' verify off
declare
    l_current_release varchar2(100) := wwv_flows_release;
begin
    -- Set build version to version in wwv_flows_release
    update wwv_flows
       set flow_version = '&PRODUCT_NAME. ' || l_current_release
     where security_group_id=10;

    -- Only execute if APEX is in sys.dba_registry to support application containers and if the APEX version is
    -- current (registry schema matches APPUN).
    if length('^APEX_SCHEMA.') > 0 then
        $if sys.dbms_db_version.version >= 18 $then
            sys.dbms_registry.set_session_namespace (
                namespace   => 'DBTOOLS');
            sys.dbms_registry.loaded (
                comp_id      => 'APEX',
                comp_version => l_current_release );
        $else
            update sys.registry$
               set version=l_current_release
             where cid='APEX';
        $end
    end if;

    commit;
end;
/

exec sys.dbms_session.modify_package_state(sys.dbms_session.reinitialize)

--==============================================================================
-- Reset Image Prefix to new CDN '^PATCH_IMAGES_VERSION.'
--==============================================================================
declare
    l_image_prefix varchar2(4000) := lower(wwv_flow_image_prefix.g_image_prefix);
    l_new_cdn      varchar2(100) := 'https://static.oracle.com/cdn/apex/^PATCH_IMAGES_VERSION./';
begin
    if l_image_prefix like 'https://static.oracle.com/cdn/apex/%' and l_image_prefix <> l_new_cdn then
        wwv_flow_instance_admin.set_parameter(
            p_parameter => 'IMAGE_PREFIX',
            p_value     => l_new_cdn );
    end if;

    update wwv_flows
       set flow_image_prefix = l_new_cdn
     where lower(flow_image_prefix) like 'https://static.oracle.com/cdn/apex/%'
       and lower(flow_image_prefix) <> l_new_cdn;

    commit;
end;
/

--==============================================================================
prompt ... Enabling Jobs
--==============================================================================
begin
    --
    -- Enable
    --
    for i in ( select j.job_name
                 from sys.dba_scheduler_jobs j,
                      ( select ( select value
                                   from ^APPUN..wwv_flow_platform_prefs
                                  where name = 'COREPATCH_DISABLED_JOBS'
                                    and id   = -1 ) disabled_jobs
                          from sys.dual )
                where owner = '^APPUN'
                  and instr (
                          disabled_jobs,
                          ':'||j.job_name||':' ) > 0
                order by 1 )
    loop
        sys.dbms_output.put_line('... enabling '||i.job_name);
        sys.dbms_scheduler.enable (
            name  => '^APPUN..'||i.job_name );
    end loop;
    --
    -- Delete helper parameter.
    --
    delete from ^APPUN..wwv_flow_platform_prefs
     where id   = -1
       and name = 'COREPATCH_DISABLED_JOBS';
    commit;
end;
/

--==============================================================================
-- Complete patch installation
--==============================================================================
set serveroutput on
prompt ...Validating APEX
begin
    --Only execute if APEX is in sys.dba_registry to support application containers
    if length('^APEX_SCHEMA.') > 0 then
        sys.validate_apex;
    end if;
end;
/

prompt ...Recompiling invalid public synonyms
declare
    procedure compile_synonym( p_synonym_name in varchar2 ) is
    begin
        execute immediate 'alter public synonym ' || sys.dbms_assert.enquote_name( p_synonym_name ) || ' compile';
    exception when others then
        sys.dbms_output.put_line( sqlerrm || ' when compiling public synonym ' || p_synonym_name );
    end;
begin
    for s in (
        select s.synonym_name
          from sys.dba_synonyms s, sys.dba_objects o
         where o.owner       = s.owner
           and o.object_name = s.synonym_name
            --
           and s.table_owner = '^APEX_SCHEMA'
           and o.status      = 'INVALID'
           and s.owner       = 'PUBLIC'
         order by s.synonym_name
    ) loop
        compile_synonym( p_synonym_name => s.synonym_name );
    end loop;
end;
/

set define '^' verify off
begin
    insert into wwv_flow_pses (patch_number, patch_version, images_version ) values ( ^PATCH_ID., '^PATCH_VERSION.', '^PATCH_IMAGES_VERSION.' );
    commit;
end;
/
