set define '^' verify off
prompt ...wwv_flows_release
create or replace function wwv_flows_release wrapped 
a000000
369
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
64 89
wJmO9PbZeWw9S5E3c7Rl2Raj0zowg8eZgcfLCNL+XhaWlm2u2fqWlkqW8tehLlbcXOfAsr2y
m17nx3TAM7h0ZQm4dIvmOdziuUE/cZ5nqcoOo3fwX9J0gVl3O75xc3HYiKbctR/z

/
